#include<stdio.h>

int main()
{
	int a, b, c;
	
	printf("������ �Է��Ͻÿ�: ");
	scanf("%d", &a);
	b = a;
	if (a >= 0)
	{
		printf("%d", a % 10);
		do
		{
			b /= 10;
				printf("%d", b%10);
		} while (b >= (a / 100));
	}
	else
	{
		printf("����\n");
	}
	printf("\n");

	return 0;
}