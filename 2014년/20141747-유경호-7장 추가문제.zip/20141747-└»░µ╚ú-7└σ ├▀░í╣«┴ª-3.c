#include<stdio.h>

int main()
{
	int a, b, c;
	
	for (a = 1; a <= 7; a++)
	{
		for (c = 1; c <= 7; c++)
		{
			if (a == 1 && c <= 6)
			{
				printf(" ");
			}
			else if (a == 1 && c <= 7)
			{
				printf("*");
			}
			if (a == 2 && c <= 5)
			{
				printf(" ");
			}
			else if (a == 2 && c <= 7)
			{
				printf("*");
			}
			if (a == 3 && c <= 4)
			{
				printf(" ");
			}
			else if (a == 3 && c <= 7)
			{
				printf("*");
			}
			if (a == 4 && c <= 3)
			{
				printf(" ");
			}
			else if (a == 4 && c <= 7)
			{
				printf("*");
			}
			if (a == 5 && c <= 2)
			{
				printf(" ");
			}
			else if (a == 5 && c <= 7)
			{
				printf("*");
			}
			if (a == 6 && c <= 1)
			{
				printf(" ");
			}
			else if (a == 6 && c <= 7)
			{
				printf("*");
			}
			if (a == 7 && c <= 0)
			{
				printf(" ");
			}
			else if (a == 7 && c <= 7)
			{
				printf("*");
			}

		}
		printf("\n");
	}

	return 0;
}