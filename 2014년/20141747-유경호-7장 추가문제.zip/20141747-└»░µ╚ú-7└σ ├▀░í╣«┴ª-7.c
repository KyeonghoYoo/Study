#include<stdio.h>

int main()
{
	int a;
	printf("2 3 ");
	for (a = 1; a <= 100; a++)
	{
		if (a>1 && !(a % 2 == 0 || a % 3 == 0))
		{
			printf("%d ", a);
		}
	}
	printf("\n");

	return 0;
}