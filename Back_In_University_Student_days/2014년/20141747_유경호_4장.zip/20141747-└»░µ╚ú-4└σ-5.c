#include<stdio.h>

int main()
{
	printf("\"ASCII code\", 'A', 'B', 'C'\n");
	printf("\\t \\a \\n\n");
	return 0;
}